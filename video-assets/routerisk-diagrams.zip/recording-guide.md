# RouteRisk diagrams for the submission video

These are 1920 × 1080 PNG cards. Use each for about 5–7 seconds between app recordings. The SVG versions are editable.

| Card | Place it after | Voiceover |
| --- | --- | --- |
| 01 — How scoring works | Showing the route options | “RouteRisk starts with public historical crash records. It weights crashes near each road segment by severity, proximity, and recency, then calculates relative exposure per mile.” |
| 02 — Route tradeoff | Moving the Faster ↔ Lower Exposure control | “Now travel time and historical exposure appear together, so the driver can choose with more information.” |
| 03 — Live incident alert | Tapping GO, before the alert preview | “During a trip, RouteRisk checks 511NJ crash reports. If a report is near the selected route and ahead of the driver, the app gives a spoken and haptic warning.” |
| 04 — Optional safety backup | The crash-check preview, if you include it | “The experimental possible-impact check gives the driver 20 seconds to cancel. Parent texts and calls need the optional delivery service configured.” |

Keep the incident alert and crash-check demonstrations labeled **Preview** on screen. The historical score is a weighted formula, not a trained machine-learning model or a prediction that a crash will occur.
